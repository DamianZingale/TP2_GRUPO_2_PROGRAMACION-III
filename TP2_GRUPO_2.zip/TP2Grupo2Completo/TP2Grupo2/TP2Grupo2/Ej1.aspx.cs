﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TP2Grupo2
{
	public partial class Ej1 : System.Web.UI.Page
	{
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGenerarTabla_Click(object sender, EventArgs e)
        {
            if (txtCant1.Text.Trim().Length > 0 && txtCant2.Text.Trim().Length > 0 &&
                  txtProd1.Text.Trim().Length > 0 && txtProd2.Text.Trim().Length > 0)
            {
                int Cantidad1 = int.Parse(txtCant1.Text);
                int Cantidad2 = int.Parse(txtCant2.Text);
                //
                string tabla = "<table border='1'>";
                tabla += "<tr><th>Producto</th><th>Cantidad</th></th>";

                tabla += "<tr>";
                tabla += "<td>" + txtProd1.Text + "</td>";
                tabla += "<td>" + Cantidad1 + "</td>";
                tabla += "</tr>";

                tabla += "<tr>";
                tabla += "<td>" + txtProd2.Text + "</td>";
                tabla += "<td>" + Cantidad2 + "</td>";
                tabla += "</tr>";

                tabla += "<tr>";
                tabla += "<td>" + "Total" + "</td>";
                tabla += "<td>" + (Cantidad1 + Cantidad2) + "</td>";
                tabla += "</tr>";

                tabla += "</table>";
                lblTabla.Text = tabla;
            }
        }
    }
}