﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TP2Grupo2
{
	public partial class Ej5 : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {


                ListItem Dosgb = new ListItem();
                Dosgb.Text = "2GB";
                Dosgb.Value = "200";
                ListItem Cuatrogb = new ListItem();
                Cuatrogb.Text = "4GB";
                Cuatrogb.Value = "375";
                ListItem Seisgb = new ListItem();
                Seisgb.Text = "6GB";
                Seisgb.Value = "500";
                ddlMemoria.Items.Add(Dosgb);
                ddlMemoria.Items.Add(Cuatrogb);
                ddlMemoria.Items.Add(Seisgb);

                ListItem monitor = new ListItem();
                monitor.Text = "MONITOR LCD";
                monitor.Value = "2000,5";
                ListItem HD500 = new ListItem();
                HD500.Text = "HD 500GB";
                HD500.Value = "500,5";
                ListItem grabador = new ListItem();
                grabador.Text = "GRABADOR DVD";
                grabador.Value = "1200";
                cblAccesorios.Items.Add(monitor);
                cblAccesorios.Items.Add(HD500);
                cblAccesorios.Items.Add(grabador);
            }
        }




        protected void btnPrecio_Click(object sender, EventArgs e)
        {
            float carga = 0;
            lblPrecio.Text = string.Empty;

            foreach (ListItem i in cblAccesorios.Items)
            {
                if (i.Selected)
                {
                    float Precio = float.Parse(i.Value);
                    carga += Precio;
                }
            }
            foreach (ListItem x in ddlMemoria.Items)
            {
                if (x.Selected)
                {
                    float precios = float.Parse(x.Value);
                    carga += precios;
                }
            }
            lblPrecio.Text ="$ " +  carga.ToString();

        }
	}
}