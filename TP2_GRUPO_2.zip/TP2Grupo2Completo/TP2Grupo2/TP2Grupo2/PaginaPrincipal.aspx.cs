﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TP2Grupo2
{
    public partial class PaginaPrincipal : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void ej1_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Ej1.aspx");

        }

        protected void ej2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Ej2.aspx");
        }
        

        protected void ej3_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/Ej3.aspx");
        }

        protected void ej4_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/Ejercicio4.aspx");
        }

        protected void ej5_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/Ej5.aspx");
        }
    }
}