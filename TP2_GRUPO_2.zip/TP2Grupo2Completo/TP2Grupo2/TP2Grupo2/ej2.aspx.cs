﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TP2Grupo2
{
	public partial class ej2 : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!IsPostBack)
			{
				///Items al DropDownList
				DropDownListCiudades.Items.Add(new ListItem("Gral. Pacheco", "Zona norte"));
				DropDownListCiudades.Items.Add(new ListItem("San Miguel", "Zona oeste"));
				DropDownListCiudades.Items.Add(new ListItem("Boedo", "Zona sur"));


				///Items pal Checkboxlist
				CheckBoxListMaterias.Items.Add("Ciencia");
				CheckBoxListMaterias.Items.Add("Literatura");
				CheckBoxListMaterias.Items.Add("Historia");

			}

		}

		protected void ButtonVerResumen_Click(object sender, EventArgs e)
		{
			///Con Session es como que encapsula/guarda todos los datos	para despues redirigirlo a otro lugar
			///lo tuve que investigar y me parecio muy interesante.

			Session["Nombre"] = TextBoxNombre.Text;
			Session["Apellido"] = TextBoxApellido.Text;
			Session["Ciudad"] = DropDownListCiudades.SelectedValue;
			Session["Temas"] = CheckBoxListMaterias.Items.Cast<ListItem>()
				.Where(li => li.Selected) //busca el/los seleccionados
				.Select(li => li.Text) // lo convierte en text
				.ToList(); //lo almacena
						   // Una vez almacenado redirige al segundo formulario
			Response.Redirect("ej2B.aspx");

		}
	}
	
}