﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TP2Grupo2
{
	public partial class ej2B : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{
            if (!IsPostBack)
            {
                // Verifica si los datos existen en Session antes de intentar acceder a ellos
                if (Session["Nombre"] != null && Session["Apellido"] != null && Session["Ciudad"] != null && Session["Temas"] != null)
                {
                    // Mostrar los datos del primer formulario en el segundo
                    LabelRecibeNombre.Text = Session["Nombre"].ToString();
                    LabelRecibeApellido.Text = Session["Apellido"].ToString();
                    LabelRecibeCiudad.Text = Session["Ciudad"].ToString();
                    LabelRecibeMaterias.Text = string.Join(", ", (List<string>)Session["Temas"]);
                }
            }

        }
	}
}