﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TP2Grupo2
{
	public partial class ejercicio4 : System.Web.UI.Page
	{
		protected void Page_Load(object sender, EventArgs e)
		{

		}

        protected void bttValidar_Click(object sender, EventArgs e)
        {
            string Usu, Cont;

            Usu = "Claudio";
            Cont = "Casas";

            if (Usu.ToLower() == tbUsu.Text.ToLower() & Cont.ToLower() == tbCont.Text.ToLower())
            {
                Response.Redirect("Ejercicio4C.aspx?Nombre=" + Usu + "&Apellido=" + Cont);
            }
        
            else
            {
                Server.Transfer("Ejercicio4b.aspx");
            }
        }
    }
}