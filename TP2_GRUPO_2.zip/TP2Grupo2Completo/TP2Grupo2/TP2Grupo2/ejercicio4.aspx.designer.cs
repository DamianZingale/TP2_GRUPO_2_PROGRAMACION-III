﻿//------------------------------------------------------------------------------
// <generado automáticamente>
//     Este código fue generado por una herramienta.
//
//     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
//     se vuelve a generar el código. 
// </generado automáticamente>
//------------------------------------------------------------------------------

namespace TP2Grupo2
{


	public partial class ejercicio4
	{

		/// <summary>
		/// Control form1.
		/// </summary>
		/// <remarks>
		/// Campo generado automáticamente.
		/// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
		/// </remarks>
		protected global::System.Web.UI.HtmlControls.HtmlForm form1;

		/// <summary>
		/// Control lblUsu.
		/// </summary>
		/// <remarks>
		/// Campo generado automáticamente.
		/// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label lblUsu;

		/// <summary>
		/// Control tbUsu.
		/// </summary>
		/// <remarks>
		/// Campo generado automáticamente.
		/// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox tbUsu;

		/// <summary>
		/// Control lblCont.
		/// </summary>
		/// <remarks>
		/// Campo generado automáticamente.
		/// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Label lblCont;

		/// <summary>
		/// Control tbCont.
		/// </summary>
		/// <remarks>
		/// Campo generado automáticamente.
		/// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
		/// </remarks>
		protected global::System.Web.UI.WebControls.TextBox tbCont;

		/// <summary>
		/// Control bttValidar.
		/// </summary>
		/// <remarks>
		/// Campo generado automáticamente.
		/// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
		/// </remarks>
		protected global::System.Web.UI.WebControls.Button bttValidar;
	}
}
